/**
 * OpenDoc — Tailwind CSS Config Extension
 * 
 * Usage: Merge into your tailwind.config.js
 * 
 *   const opendocTheme = require('./opendoc-tailwind-extend');
 *   module.exports = {
 *     theme: { extend: opendocTheme },
 *   };
 */

module.exports = {
  colors: {
    'od-navy': '#0C1929',
    'od-offwhite': '#F5F3EF',

    'od-active': '#22C55E',
    'od-active-bg': '#14532D',
    'od-active-surface': '#F0FDF4',

    'od-decision': '#F59E0B',
    'od-decision-bg': '#451A03',
    'od-decision-surface': '#FFFBEB',

    'od-notauth': '#EF4444',
    'od-notauth-bg': '#450A0A',
    'od-notauth-surface': '#FEF2F2',
  },

  fontFamily: {
    'od-primary': ["'Plus Jakarta Sans'", 'sans-serif'],
    'od-mono': ["'JetBrains Mono'", "'SF Mono'", "'Fira Code'", 'monospace'],
  },
};
