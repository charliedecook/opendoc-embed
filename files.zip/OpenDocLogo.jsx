/**
 * OpenDoc Logo Component
 * 
 * Usage:
 *   <OpenDocLogo />                          — Full lockup, navy
 *   <OpenDocLogo variant="reversed" />       — Full lockup, white (for dark backgrounds)
 *   <OpenDocLogo variant="mark" />           — Pulse mark only, navy
 *   <OpenDocLogo variant="mark" reversed />  — Pulse mark only, white
 *   <OpenDocLogo variant="wordmark" />       — Wordmark only, navy
 *   <OpenDocLogo variant="appicon" />        — App icon with container
 *   <OpenDocLogo variant="appicon" state="active" />   — Green state icon
 *   <OpenDocLogo variant="appicon" state="decision" /> — Amber state icon
 *   <OpenDocLogo variant="appicon" state="notauth" />  — Red flatline icon
 *   <OpenDocLogo variant="mark" state="active" />      — Green pulse, no container
 *   <OpenDocLogo variant="mark" state="notauth" />     — Red flatline, no container
 */

import React from 'react';

const STATE_CONFIG = {
  default: { stroke: '#0C1929', bg: '#0C1929' },
  active: { stroke: '#22C55E', bg: '#14532D' },
  decision: { stroke: '#F59E0B', bg: '#451A03' },
  notauth: { stroke: '#EF4444', bg: '#450A0A' },
};

// The pulse waveform — 7 points defining the single-peak verification pulse
const PULSE_POINTS = '0,50 25,50 37.5,50 50,6.25 62.5,90.625 75,50 100,50';

// Flatline for NOT AUTHORIZED state
const FLATLINE_POINTS = '0,50 100,50';

function PulseMark({ color = '#0C1929', isFlat = false, size = 80 }) {
  const h = size * 0.8; // maintain 1.25:1 aspect ratio
  const strokeW = h * 0.0875;
  const points = isFlat ? FLATLINE_POINTS : PULSE_POINTS;

  // Convert percentage points to actual coordinates
  const actualPoints = points
    .split(' ')
    .map(p => {
      const [x, y] = p.split(',').map(Number);
      return `${(x / 100) * size},${(y / 100) * h}`;
    })
    .join(' ');

  return (
    <svg
      viewBox={`0 0 ${size} ${h}`}
      width={size}
      height={h}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <polyline
        points={actualPoints}
        fill="none"
        stroke={color}
        strokeWidth={strokeW}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function AppIcon({ state = 'default', size = 512 }) {
  const config = STATE_CONFIG[state] || STATE_CONFIG.default;
  const isFlat = state === 'notauth';
  const strokeColor = state === 'default' ? '#FFFFFF' : config.stroke;
  const r = size * 0.2109; // iOS superellipse radius
  const inset = size * 0.1875;
  const inner = size - inset * 2;
  const strokeW = inner * 0.0875;

  // Convert percentage points to actual coordinates within the inset area
  const points = isFlat ? FLATLINE_POINTS : PULSE_POINTS;
  const actualPoints = points
    .split(' ')
    .map(p => {
      const [x, y] = p.split(',').map(Number);
      return `${inset + (x / 100) * inner},${inset + (y / 100) * (inner * 0.8)}`;
    })
    .join(' ');

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      width={size}
      height={size}
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={`OpenDoc ${state} icon`}
    >
      <rect x="0" y="0" width={size} height={size} rx={r} fill={config.bg} />
      <polyline
        points={actualPoints}
        fill="none"
        stroke={strokeColor}
        strokeWidth={strokeW}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function Wordmark({ color = '#0C1929', fontSize = 48 }) {
  return (
    <span
      style={{
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 700,
        fontSize: `${fontSize}px`,
        letterSpacing: '-0.02em',
        color,
        lineHeight: 1,
        whiteSpace: 'nowrap',
      }}
    >
      OpenDoc
    </span>
  );
}

export default function OpenDocLogo({
  variant = 'lockup',    // 'lockup' | 'mark' | 'wordmark' | 'appicon'
  reversed = false,       // swap to white (only for lockup, mark, wordmark)
  state = null,           // 'active' | 'decision' | 'notauth' | null
  size = 'md',            // 'sm' | 'md' | 'lg' | 'xl' or a number (px)
  className = '',
}) {
  // Size mapping
  const sizeMap = { sm: 24, md: 48, lg: 80, xl: 120 };
  const markSize = typeof size === 'number' ? size : (sizeMap[size] || 48);

  // Determine colors
  const stateConfig = state ? STATE_CONFIG[state] : null;
  const isFlat = state === 'notauth';

  let markColor;
  if (stateConfig) {
    markColor = stateConfig.stroke;
  } else if (reversed) {
    markColor = '#FFFFFF';
  } else {
    markColor = '#0C1929';
  }

  const textColor = reversed ? '#FFFFFF' : '#0C1929';

  if (variant === 'appicon') {
    return <AppIcon state={state || 'default'} size={markSize} />;
  }

  if (variant === 'mark') {
    return <PulseMark color={markColor} isFlat={isFlat} size={markSize} />;
  }

  if (variant === 'wordmark') {
    const fontScale = markSize * 0.6;
    return <Wordmark color={textColor} fontSize={fontScale} />;
  }

  // Default: full lockup (mark + wordmark)
  const gap = markSize * 0.325;
  const fontScale = markSize * 0.6;

  return (
    <div
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: `${gap}px`,
      }}
      role="img"
      aria-label="OpenDoc"
    >
      <PulseMark color={markColor} isFlat={isFlat} size={markSize} />
      <Wordmark color={textColor} fontSize={fontScale} />
    </div>
  );
}
