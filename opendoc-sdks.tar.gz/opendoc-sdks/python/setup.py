from setuptools import setup, find_packages

setup(
    name="opendoc",
    version="1.1.0",
    description="OpenDoc Platform SDK — Healthcare transaction infrastructure",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="OpenDoc",
    author_email="platform@opendoc.com",
    url="https://github.com/opendoc/opendoc-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],  # Zero dependencies — stdlib only
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
)
