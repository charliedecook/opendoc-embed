"""
OpenDoc Platform SDK for Python

Healthcare transaction infrastructure. Resolve intent to bounded,
pre-priced healthcare transactions.

Usage:
    from opendoc import OpenDoc

    client = OpenDoc(api_key="sk_sandbox_...")
    
    # Resolve patient intent to care
    resolution = client.resolve.to_care(
        intent_type="COMPLAINT",
        intent_id="complaint.knee_pain",
        geo={"postal_code": "30114"},
    )

    # Create a Health Key
    health_key = client.health_keys.create(
        patient_id="...",
        offer_id=resolution.provider_candidates[0].offer_id,
    )
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode


__version__ = "1.1.0"

PRODUCTION_URL = "https://api.opendoc.com/v1"
SANDBOX_URL = "https://sandbox.api.opendoc.com/v1"


# ── Exceptions ────────────────────────────────────────────────


class OpenDocError(Exception):
    """Base exception for OpenDoc API errors."""

    def __init__(self, code: str, message: str, status: int = 400, details: dict = None):
        self.code = code
        self.message = message
        self.status = status
        self.details = details or {}
        super().__init__(f"[{code}] {message}")


class AuthenticationError(OpenDocError):
    pass


class ValidationError(OpenDocError):
    pass


class NotFoundError(OpenDocError):
    pass


class InvalidStateTransitionError(OpenDocError):
    pass


class ConsentRequiredError(OpenDocError):
    """Raised when a higher consent tier is needed."""

    def __init__(self, message: str, required_tier: str, consent_url: str, **kwargs):
        self.required_tier = required_tier
        self.consent_url = consent_url
        super().__init__("CONSENT_REQUIRED", message, 403, **kwargs)


class RateLimitError(OpenDocError):
    def __init__(self, message: str, retry_after: int = 60, **kwargs):
        self.retry_after = retry_after
        super().__init__("RATE_LIMITED", message, 429, **kwargs)


# ── Response wrapper ──────────────────────────────────────────


class APIObject:
    """Dict-like object that allows attribute access on API responses."""

    def __init__(self, data: dict):
        self._data = data
        for key, value in data.items():
            if isinstance(value, dict):
                setattr(self, key, APIObject(value))
            elif isinstance(value, list):
                setattr(self, key, [
                    APIObject(v) if isinstance(v, dict) else v for v in value
                ])
            else:
                setattr(self, key, value)

    def __getitem__(self, key):
        return self._data[key]

    def __contains__(self, key):
        return key in self._data

    def get(self, key, default=None):
        return self._data.get(key, default)

    def to_dict(self) -> dict:
        return self._data

    def __repr__(self):
        keys = list(self._data.keys())[:5]
        preview = ", ".join(f"{k}={self._data[k]!r}" for k in keys)
        if len(self._data) > 5:
            preview += ", ..."
        return f"APIObject({preview})"


class ListResponse(APIObject):
    """Paginated list response with iteration support."""

    def __iter__(self):
        return iter(self.data if hasattr(self, 'data') else [])

    def __len__(self):
        return len(self.data) if hasattr(self, 'data') else 0


# ── HTTP Transport ────────────────────────────────────────────


class _Transport:
    def __init__(self, api_key: str, base_url: str, timeout: int, max_retries: int):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

    def request(
        self,
        method: str,
        path: str,
        params: dict = None,
        body: dict = None,
        idempotency_key: str = None,
    ) -> dict:
        url = f"{self.base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url += "?" + urlencode(filtered, doseq=True)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"opendoc-python/{__version__}",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data = json.dumps(body).encode() if body else None

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                req = Request(url, data=data, headers=headers, method=method)
                with urlopen(req, timeout=self.timeout) as resp:
                    return json.loads(resp.read().decode())
            except HTTPError as e:
                response_body = json.loads(e.read().decode()) if e.fp else {}
                error_code = response_body.get("code", "UNKNOWN")
                error_msg = response_body.get("message", str(e))
                details = response_body.get("details", {})

                if e.code == 401:
                    raise AuthenticationError(error_code, error_msg, e.code, details)
                elif e.code == 403 and error_code == "CONSENT_REQUIRED":
                    raise ConsentRequiredError(
                        error_msg,
                        required_tier=details.get("required_tier", ""),
                        consent_url=details.get("consent_url", ""),
                    )
                elif e.code == 404:
                    raise NotFoundError(error_code, error_msg, e.code, details)
                elif e.code == 409 and error_code == "INVALID_STATE_TRANSITION":
                    raise InvalidStateTransitionError(error_code, error_msg, e.code, details)
                elif e.code == 429:
                    retry_after = int(e.headers.get("Retry-After", 60))
                    if attempt < self.max_retries:
                        time.sleep(retry_after)
                        continue
                    raise RateLimitError(error_msg, retry_after=retry_after)
                elif e.code >= 500 and attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    last_error = e
                    continue
                else:
                    raise OpenDocError(error_code, error_msg, e.code, details)

        if last_error:
            raise OpenDocError("INTERNAL", f"Request failed after {self.max_retries + 1} attempts")


# ── Resource Classes ──────────────────────────────────────────


class Taxonomy:
    """Canonical clinical and service taxonomies."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list_complaints(self, q: str = None, specialty: str = None,
                        cursor: str = None, limit: int = None) -> ListResponse:
        """Search the symptom/complaint catalog."""
        return ListResponse(self._t.request("GET", "/taxonomy/complaints",
            params={"q": q, "specialty": specialty, "cursor": cursor, "limit": limit}))

    def get_complaint(self, complaint_id: str) -> APIObject:
        """Get a specific complaint with mapped HSOs and discriminators."""
        return APIObject(self._t.request("GET", f"/taxonomy/complaints/{complaint_id}"))

    def list_diagnoses(self, q: str = None, specialty: str = None,
                       cursor: str = None, limit: int = None) -> ListResponse:
        """Search the diagnosis catalog."""
        return ListResponse(self._t.request("GET", "/taxonomy/diagnoses",
            params={"q": q, "specialty": specialty, "cursor": cursor, "limit": limit}))

    def get_diagnosis(self, diagnosis_id: str) -> APIObject:
        """Get a specific diagnosis with mapped HSOs and care phases."""
        return APIObject(self._t.request("GET", f"/taxonomy/diagnoses/{diagnosis_id}"))

    def list_scope_codes(self, type: str = None, category: str = None) -> ListResponse:
        """List controlled vocabulary for mHSO scope definitions."""
        return ListResponse(self._t.request("GET", "/taxonomy/scope-codes",
            params={"type": type, "category": category}))

    def list_specialties(self) -> ListResponse:
        """List specialty and subspecialty classifications."""
        return ListResponse(self._t.request("GET", "/taxonomy/specialties"))


class HSOs:
    """The canonical HSO catalog. Read-only."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list(self, specialty: str = None, subspecialty: str = None,
             category: str = None, q: str = None, geo: str = None,
             radius_miles: int = None, medicare_excluded: bool = None,
             membership_eligible: bool = None,
             cursor: str = None, limit: int = None) -> ListResponse:
        """Search the HSO catalog."""
        return ListResponse(self._t.request("GET", "/hsos", params={
            "specialty": specialty, "subspecialty": subspecialty, "category": category,
            "q": q, "geo": geo, "radius_miles": radius_miles,
            "medicare_excluded": medicare_excluded, "membership_eligible": membership_eligible,
            "cursor": cursor, "limit": limit,
        }))

    def get(self, hso_id: str) -> APIObject:
        """Get a single HSO by its semantic dot-notation ID."""
        return APIObject(self._t.request("GET", f"/hsos/{hso_id}"))

    def list_offers(self, hso_id: str, geo: str = None, radius_miles: int = None,
                    cursor: str = None, limit: int = None) -> ListResponse:
        """List providers who offer this HSO."""
        return ListResponse(self._t.request("GET", f"/hsos/{hso_id}/offers",
            params={"geo": geo, "radius_miles": radius_miles, "cursor": cursor, "limit": limit}))


class Providers:
    """Provider directory and management."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list(self, q: str = None, specialty: str = None, geo: str = None,
             radius_miles: int = None, medicare_opted_out: bool = None,
             accepting_new_patients: bool = None,
             cursor: str = None, limit: int = None) -> ListResponse:
        """Search the provider directory."""
        return ListResponse(self._t.request("GET", "/providers", params={
            "q": q, "specialty": specialty, "geo": geo, "radius_miles": radius_miles,
            "medicare_opted_out": medicare_opted_out,
            "accepting_new_patients": accepting_new_patients,
            "cursor": cursor, "limit": limit,
        }))

    def create(self, *, npi: str, display_name: str, specialty: str,
               locations: list, **kwargs) -> APIObject:
        """Activate a provider on the platform."""
        return APIObject(self._t.request("POST", "/providers", body={
            "npi": npi, "display_name": display_name, "specialty": specialty,
            "locations": locations, **kwargs,
        }))

    def get(self, provider_id: str) -> APIObject:
        """Get provider detail."""
        return APIObject(self._t.request("GET", f"/providers/{provider_id}"))

    def update(self, provider_id: str, **kwargs) -> APIObject:
        """Update provider details."""
        return APIObject(self._t.request("PATCH", f"/providers/{provider_id}", body=kwargs))

    def list_offers(self, provider_id: str, location_id: str = None,
                    cursor: str = None, limit: int = None) -> ListResponse:
        """List all offers from a provider."""
        return ListResponse(self._t.request("GET", f"/providers/{provider_id}/offers",
            params={"location_id": location_id, "cursor": cursor, "limit": limit}))


class Offers:
    """Provider × HSO × Location × Cash Price bindings."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def create(self, *, provider_id: str, hso_id: str, location_id: str,
               price_cents: int, **kwargs) -> APIObject:
        """Create an offer. The price must be the real, deliverable cash price."""
        return APIObject(self._t.request("POST", "/offers", body={
            "provider_id": provider_id, "hso_id": hso_id,
            "location_id": location_id, "price_cents": price_cents, **kwargs,
        }))

    def get(self, offer_id: str) -> APIObject:
        """Get offer detail."""
        return APIObject(self._t.request("GET", f"/offers/{offer_id}"))

    def update(self, offer_id: str, **kwargs) -> APIObject:
        """Update offer price or availability. Prospective only — Cash Price Invariant enforced."""
        return APIObject(self._t.request("PATCH", f"/offers/{offer_id}", body=kwargs))

    def retire(self, offer_id: str) -> APIObject:
        """Permanently retire an offer. Existing Health Keys unaffected."""
        return APIObject(self._t.request("DELETE", f"/offers/{offer_id}"))


class Resolve:
    """The Clinical Routing Engine."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def to_care(self, *, intent_type: str, intent_id: str, geo: dict,
                patient_id: str = None, time_window: dict = None,
                financial_context: dict = None, patient_preferences: dict = None,
                clinical_context_refs: list = None) -> APIObject:
        """
        Resolve patient intent to bounded transaction candidates.

        All prices returned are cash prices. Always HIGH confidence.
        The response includes a confirmation_url — no transaction without
        explicit patient confirmation.
        """
        body = {
            "intent_type": intent_type,
            "intent_id": intent_id,
            "geo": geo,
        }
        if patient_id:
            body["patient_id"] = patient_id
        if time_window:
            body["time_window"] = time_window
        if financial_context:
            body["financial_context"] = financial_context
        if patient_preferences:
            body["patient_preferences"] = patient_preferences
        if clinical_context_refs:
            body["clinical_context_refs"] = clinical_context_refs

        return APIObject(self._t.request("POST", "/resolve", body=body))


class Patients:
    """Patient identity management."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def create(self, *, full_name: str, date_of_birth: str, **kwargs) -> APIObject:
        """Register a patient."""
        return APIObject(self._t.request("POST", "/patients",
            body={"full_name": full_name, "date_of_birth": date_of_birth, **kwargs}))

    def get(self, patient_id: str) -> APIObject:
        """Get patient identity (not clinical data)."""
        return APIObject(self._t.request("GET", f"/patients/{patient_id}"))


class HealthKeys:
    """Health Key lifecycle management."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list(self, patient_id: str = None, provider_id: str = None,
             state: Union[str, list] = None, created_after: str = None,
             created_before: str = None,
             cursor: str = None, limit: int = None) -> ListResponse:
        """List Health Keys with filters."""
        return ListResponse(self._t.request("GET", "/health-keys", params={
            "patient_id": patient_id, "provider_id": provider_id, "state": state,
            "created_after": created_after, "created_before": created_before,
            "cursor": cursor, "limit": limit,
        }))

    def create(self, *, patient_id: str, offer_id: str,
               resolution_id: str = None, scheduled_at: str = None) -> APIObject:
        """Create a Health Key in READY state."""
        body = {"patient_id": patient_id, "offer_id": offer_id}
        if resolution_id:
            body["resolution_id"] = resolution_id
        if scheduled_at:
            body["scheduled_at"] = scheduled_at
        return APIObject(self._t.request("POST", "/health-keys", body=body))

    def get(self, health_key_id: str) -> APIObject:
        """Get Health Key state and detail."""
        return APIObject(self._t.request("GET", f"/health-keys/{health_key_id}"))

    def authorize(self, health_key_id: str, confirmation_artifact: str = "") -> APIObject:
        """
        Patient authorizes the Health Key. READY → ACTIVE.
        Requires funding_state = FUNDED.
        """
        return APIObject(self._t.request("POST", f"/health-keys/{health_key_id}/authorize",
            body={"patient_confirmation": True, "confirmation_artifact": confirmation_artifact}))

    def complete(self, health_key_id: str, *, pos_type: str, pos_tier: int = 1,
                 attested_by: str = None, artifacts: list = None) -> APIObject:
        """Attest service completion (Proof of Service). ACTIVE → COMPLETED."""
        body = {"pos_type": pos_type, "pos_tier": pos_tier}
        if attested_by:
            body["attested_by"] = attested_by
        if artifacts:
            body["artifacts"] = artifacts
        return APIObject(self._t.request("POST", f"/health-keys/{health_key_id}/complete", body=body))

    def cancel(self, health_key_id: str, *, initiated_by: str,
               reason: str = None) -> APIObject:
        """Cancel the Health Key."""
        body = {"initiated_by": initiated_by}
        if reason:
            body["reason"] = reason
        return APIObject(self._t.request("POST", f"/health-keys/{health_key_id}/cancel", body=body))

    def get_qr(self, health_key_id: str, format: str = "json") -> APIObject:
        """Get the QR authority token payload."""
        return APIObject(self._t.request("GET", f"/health-keys/{health_key_id}/qr",
            params={"format": format}))

    def scan(self, qr_token: str, scanner_provider_id: str = None) -> APIObject:
        """Scan and verify a Health Key QR code. The boarding-pass moment."""
        body = {"qr_token": qr_token}
        if scanner_provider_id:
            body["scanner_provider_id"] = scanner_provider_id
        return APIObject(self._t.request("POST", "/scan", body=body))


class Funding:
    """Multi-source funding orchestration."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def get(self, health_key_id: str) -> APIObject:
        """Get funding status for a Health Key."""
        return APIObject(self._t.request("GET", f"/health-keys/{health_key_id}/funding"))

    def add(self, health_key_id: str, *, source_type: str, amount_cents: int,
            payment_method_token: str, funder_id: str = None, **kwargs) -> APIObject:
        """Add a funding contribution."""
        body = {
            "source_type": source_type,
            "amount_cents": amount_cents,
            "payment_method_token": payment_method_token,
        }
        if funder_id:
            body["funder_id"] = funder_id
        body.update(kwargs)
        return APIObject(self._t.request("POST", f"/health-keys/{health_key_id}/funding", body=body))

    def create_link(self, health_key_id: str, funder_type: str = "INDIVIDUAL",
                    suggested_amount_cents: int = None, expires_at: str = None) -> APIObject:
        """Create a shareable funding link."""
        body = {"health_key_id": health_key_id, "funder_type": funder_type}
        if suggested_amount_cents:
            body["suggested_amount_cents"] = suggested_amount_cents
        if expires_at:
            body["expires_at"] = expires_at
        return APIObject(self._t.request("POST", "/funding-links", body=body))


class Settlement:
    """Event-based settlement and disputes."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def get(self, health_key_id: str) -> APIObject:
        """Get settlement status."""
        return APIObject(self._t.request("GET", f"/health-keys/{health_key_id}/settlement"))

    def create_dispute(self, health_key_id: str, *, reason: str,
                       description: str = None, evidence_refs: list = None) -> APIObject:
        """Open a dispute within the dispute window."""
        body = {"reason": reason}
        if description:
            body["description"] = description
        if evidence_refs:
            body["evidence_refs"] = evidence_refs
        return APIObject(self._t.request("POST", f"/health-keys/{health_key_id}/disputes", body=body))


class MembershipTiers:
    """Membership tier management (provider-side)."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list(self, template: str = None, geo: str = None, radius_miles: int = None,
             provider_id: str = None, hsa_eligible: bool = None,
             capacity_state: str = None,
             cursor: str = None, limit: int = None) -> ListResponse:
        """Search membership tiers."""
        return ListResponse(self._t.request("GET", "/membership-tiers", params={
            "template": template, "geo": geo, "radius_miles": radius_miles,
            "provider_id": provider_id, "hsa_eligible": hsa_eligible,
            "capacity_state": capacity_state, "cursor": cursor, "limit": limit,
        }))

    def create(self, *, provider_id: str, name: str, template: str,
               fee_cents: int, fee_cadence: str, term_months: int,
               included_scope: list, excluded_scope: list, **kwargs) -> APIObject:
        """Create a membership tier (DRAFT state)."""
        return APIObject(self._t.request("POST", "/membership-tiers", body={
            "provider_id": provider_id, "name": name, "template": template,
            "fee_cents": fee_cents, "fee_cadence": fee_cadence,
            "term_months": term_months, "included_scope": included_scope,
            "excluded_scope": excluded_scope, **kwargs,
        }))

    def get(self, tier_id: str) -> APIObject:
        return APIObject(self._t.request("GET", f"/membership-tiers/{tier_id}"))

    def update(self, tier_id: str, **kwargs) -> APIObject:
        return APIObject(self._t.request("PATCH", f"/membership-tiers/{tier_id}", body=kwargs))

    def activate(self, tier_id: str) -> APIObject:
        """Transition DRAFT → ACTIVE."""
        return APIObject(self._t.request("POST", f"/membership-tiers/{tier_id}/activate"))

    def retire(self, tier_id: str) -> APIObject:
        """Transition ACTIVE → RETIRED."""
        return APIObject(self._t.request("POST", f"/membership-tiers/{tier_id}/retire"))


class Memberships:
    """Patient membership lifecycle."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def create(self, *, patient_id: str, tier_id: str, payment_method_id: str,
               renewal_mode: str = "AUTO") -> APIObject:
        """Enroll patient in a membership tier."""
        return APIObject(self._t.request("POST", "/memberships", body={
            "patient_id": patient_id, "tier_id": tier_id,
            "payment_method_id": payment_method_id, "renewal_mode": renewal_mode,
        }))

    def get(self, membership_id: str) -> APIObject:
        return APIObject(self._t.request("GET", f"/memberships/{membership_id}"))

    def renew(self, membership_id: str, payment_method_id: str = None) -> APIObject:
        body = {}
        if payment_method_id:
            body["payment_method_id"] = payment_method_id
        return APIObject(self._t.request("POST", f"/memberships/{membership_id}/renew", body=body or None))

    def cancel(self, membership_id: str, reason: str = None) -> APIObject:
        body = {"reason": reason} if reason else {}
        return APIObject(self._t.request("POST", f"/memberships/{membership_id}/cancel", body=body or None))

    def initiate_excluded_service(self, membership_id: str, *, hso_id: str,
                                  preferred_provider_id: str = None,
                                  notes: str = None) -> APIObject:
        """Initiate excluded-service handoff (Rail B)."""
        body = {"hso_id": hso_id}
        if preferred_provider_id:
            body["preferred_provider_id"] = preferred_provider_id
        if notes:
            body["notes"] = notes
        return APIObject(self._t.request("POST", f"/memberships/{membership_id}/excluded-service", body=body))


class Consent:
    """Tiered patient consent management."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list_grants(self) -> ListResponse:
        return ListResponse(self._t.request("GET", "/consent/grants"))

    def request_grant(self, *, patient_id: str, tier: str, purpose: str,
                      grant_type: str = "SESSION_ONLY", scopes: list = None) -> APIObject:
        body = {"patient_id": patient_id, "tier": tier, "purpose": purpose, "grant_type": grant_type}
        if scopes:
            body["scopes"] = scopes
        return APIObject(self._t.request("POST", "/consent/grants", body=body))

    def revoke_grant(self, grant_id: str, reason: str = None) -> APIObject:
        body = {"reason": reason} if reason else {}
        return APIObject(self._t.request("POST", f"/consent/grants/{grant_id}/revoke", body=body or None))


class Audit:
    """Patient-visible access history."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def access_log(self, client_id: str = None, since: str = None,
                   cursor: str = None, limit: int = None) -> ListResponse:
        return ListResponse(self._t.request("GET", "/audit/access-log",
            params={"client_id": client_id, "since": since, "cursor": cursor, "limit": limit}))


class Webhooks:
    """Webhook endpoint management."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def list(self) -> APIObject:
        return APIObject(self._t.request("GET", "/webhooks"))

    def create(self, *, url: str, events: list) -> APIObject:
        return APIObject(self._t.request("POST", "/webhooks", body={"url": url, "events": events}))

    def update(self, webhook_id: str, **kwargs) -> APIObject:
        return APIObject(self._t.request("PATCH", f"/webhooks/{webhook_id}", body=kwargs))

    def delete(self, webhook_id: str) -> None:
        self._t.request("DELETE", f"/webhooks/{webhook_id}")

    def test(self, webhook_id: str, event_type: str = "health_key.created") -> APIObject:
        return APIObject(self._t.request("POST", f"/webhooks/{webhook_id}/test",
            body={"event_type": event_type}))


class Platform:
    """Client registration and usage."""

    def __init__(self, transport: _Transport):
        self._t = transport

    def register_client(self, *, name: str, redirect_uris: list,
                        contact_email: str, **kwargs) -> APIObject:
        return APIObject(self._t.request("POST", "/clients", body={
            "name": name, "redirect_uris": redirect_uris,
            "contact_email": contact_email, **kwargs,
        }))

    def me(self) -> APIObject:
        return APIObject(self._t.request("GET", "/clients/me"))

    def usage(self, period: str = "this_month") -> APIObject:
        return APIObject(self._t.request("GET", "/clients/me/usage", params={"period": period}))


# ── Main Client ───────────────────────────────────────────────


class OpenDoc:
    """
    OpenDoc Platform API client.

    Args:
        api_key: Your API key (starts with sk_sandbox_ or sk_live_)
        base_url: Override the base URL (defaults based on key prefix)
        timeout: Request timeout in seconds
        max_retries: Max retries on 5xx and 429 errors
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: int = 30,
        max_retries: int = 2,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        if base_url is None:
            base_url = SANDBOX_URL if api_key.startswith("sk_sandbox_") else PRODUCTION_URL

        transport = _Transport(api_key, base_url, timeout, max_retries)

        self.taxonomy = Taxonomy(transport)
        self.hsos = HSOs(transport)
        self.providers = Providers(transport)
        self.offers = Offers(transport)
        self.resolve = Resolve(transport)
        self.patients = Patients(transport)
        self.health_keys = HealthKeys(transport)
        self.funding = Funding(transport)
        self.settlement = Settlement(transport)
        self.membership_tiers = MembershipTiers(transport)
        self.memberships = Memberships(transport)
        self.consent = Consent(transport)
        self.audit = Audit(transport)
        self.webhooks = Webhooks(transport)
        self.platform = Platform(transport)
