/**
 * OpenDoc Platform SDK for Node.js
 *
 * Healthcare transaction infrastructure. Resolve intent to bounded,
 * pre-priced healthcare transactions.
 *
 * @example
 * const { OpenDoc } = require('@opendoc/sdk');
 *
 * const client = new OpenDoc('sk_sandbox_...');
 *
 * const resolution = await client.resolve.toCare({
 *   intentType: 'COMPLAINT',
 *   intentId: 'complaint.knee_pain',
 *   geo: { postalCode: '30114' },
 * });
 *
 * const healthKey = await client.healthKeys.create({
 *   patientId: '...',
 *   offerId: resolution.providerCandidates[0].offerId,
 * });
 */

'use strict';

const https = require('https');
const http = require('http');
const { URL, URLSearchParams } = require('url');

const VERSION = '1.1.0';
const PRODUCTION_URL = 'https://api.opendoc.com/v1';
const SANDBOX_URL = 'https://sandbox.api.opendoc.com/v1';

// ── Errors ───────────────────────────────────────────────────

class OpenDocError extends Error {
  constructor(code, message, status = 400, details = {}) {
    super(`[${code}] ${message}`);
    this.name = 'OpenDocError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

class AuthenticationError extends OpenDocError {
  constructor(msg, details) { super('UNAUTHORIZED', msg, 401, details); this.name = 'AuthenticationError'; }
}

class NotFoundError extends OpenDocError {
  constructor(msg, details) { super('NOT_FOUND', msg, 404, details); this.name = 'NotFoundError'; }
}

class InvalidStateTransitionError extends OpenDocError {
  constructor(msg, details) { super('INVALID_STATE_TRANSITION', msg, 409, details); this.name = 'InvalidStateTransitionError'; }
}

class ConsentRequiredError extends OpenDocError {
  constructor(msg, details) {
    super('CONSENT_REQUIRED', msg, 403, details);
    this.name = 'ConsentRequiredError';
    this.requiredTier = details.required_tier || '';
    this.consentUrl = details.consent_url || '';
  }
}

class RateLimitError extends OpenDocError {
  constructor(msg, retryAfter = 60) {
    super('RATE_LIMITED', msg, 429);
    this.name = 'RateLimitError';
    this.retryAfter = retryAfter;
  }
}

// ── Transport ────────────────────────────────────────────────

class Transport {
  constructor(apiKey, baseUrl, timeout, maxRetries) {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.timeout = timeout;
    this.maxRetries = maxRetries;
  }

  async request(method, path, { params, body, idempotencyKey } = {}) {
    let url = `${this.baseUrl}${path}`;
    if (params) {
      const filtered = Object.fromEntries(Object.entries(params).filter(([, v]) => v != null));
      if (Object.keys(filtered).length > 0) {
        url += '?' + new URLSearchParams(filtered).toString();
      }
    }

    const headers = {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'User-Agent': `opendoc-node/${VERSION}`,
    };
    if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;

    const payload = body ? JSON.stringify(body) : undefined;
    let lastError;

    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        const result = await this._fetch(method, url, headers, payload);
        return result;
      } catch (err) {
        if (err instanceof RateLimitError && attempt < this.maxRetries) {
          await new Promise(r => setTimeout(r, err.retryAfter * 1000));
          continue;
        }
        if (err.status >= 500 && attempt < this.maxRetries) {
          await new Promise(r => setTimeout(r, Math.pow(2, attempt) * 1000));
          lastError = err;
          continue;
        }
        throw err;
      }
    }
    throw lastError || new OpenDocError('INTERNAL', 'Request failed after retries');
  }

  _fetch(method, url, headers, payload) {
    return new Promise((resolve, reject) => {
      const parsed = new URL(url);
      const transport = parsed.protocol === 'https:' ? https : http;
      const opts = {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method,
        headers,
        timeout: this.timeout * 1000,
      };

      const req = transport.request(opts, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          let parsed;
          try { parsed = JSON.parse(data); } catch { parsed = {}; }

          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            const code = parsed.code || 'UNKNOWN';
            const msg = parsed.message || `HTTP ${res.statusCode}`;
            const details = parsed.details || {};

            if (res.statusCode === 401) reject(new AuthenticationError(msg, details));
            else if (res.statusCode === 403 && code === 'CONSENT_REQUIRED') reject(new ConsentRequiredError(msg, details));
            else if (res.statusCode === 404) reject(new NotFoundError(msg, details));
            else if (res.statusCode === 409 && code === 'INVALID_STATE_TRANSITION') reject(new InvalidStateTransitionError(msg, details));
            else if (res.statusCode === 429) reject(new RateLimitError(msg, parseInt(res.headers['retry-after'] || '60')));
            else reject(new OpenDocError(code, msg, res.statusCode, details));
          }
        });
      });

      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new OpenDocError('TIMEOUT', 'Request timed out')); });
      if (payload) req.write(payload);
      req.end();
    });
  }
}

// ── Resource Classes ─────────────────────────────────────────

class Taxonomy {
  constructor(t) { this._t = t; }
  listComplaints(params = {}) { return this._t.request('GET', '/taxonomy/complaints', { params }); }
  getComplaint(id) { return this._t.request('GET', `/taxonomy/complaints/${id}`); }
  listDiagnoses(params = {}) { return this._t.request('GET', '/taxonomy/diagnoses', { params }); }
  getDiagnosis(id) { return this._t.request('GET', `/taxonomy/diagnoses/${id}`); }
  listScopeCodes(params = {}) { return this._t.request('GET', '/taxonomy/scope-codes', { params }); }
  listSpecialties() { return this._t.request('GET', '/taxonomy/specialties'); }
}

class HSOs {
  constructor(t) { this._t = t; }
  list(params = {}) { return this._t.request('GET', '/hsos', { params }); }
  get(hsoId) { return this._t.request('GET', `/hsos/${hsoId}`); }
  listOffers(hsoId, params = {}) { return this._t.request('GET', `/hsos/${hsoId}/offers`, { params }); }
}

class Providers {
  constructor(t) { this._t = t; }
  list(params = {}) { return this._t.request('GET', '/providers', { params }); }
  create(body) { return this._t.request('POST', '/providers', { body }); }
  get(id) { return this._t.request('GET', `/providers/${id}`); }
  update(id, body) { return this._t.request('PATCH', `/providers/${id}`, { body }); }
  listOffers(id, params = {}) { return this._t.request('GET', `/providers/${id}/offers`, { params }); }
}

class Offers {
  constructor(t) { this._t = t; }
  /** Create an offer. The price must be the real, deliverable cash price. */
  create(body) { return this._t.request('POST', '/offers', { body }); }
  get(id) { return this._t.request('GET', `/offers/${id}`); }
  /** Update price or availability. Prospective only. */
  update(id, body) { return this._t.request('PATCH', `/offers/${id}`, { body }); }
  retire(id) { return this._t.request('DELETE', `/offers/${id}`); }
}

class Resolve {
  constructor(t) { this._t = t; }
  /**
   * Resolve patient intent to bounded transaction candidates.
   * All prices returned are cash prices. Always HIGH confidence.
   */
  toCare(body) { return this._t.request('POST', '/resolve', { body }); }
}

class Patients {
  constructor(t) { this._t = t; }
  create(body) { return this._t.request('POST', '/patients', { body }); }
  get(id) { return this._t.request('GET', `/patients/${id}`); }
}

class HealthKeys {
  constructor(t) { this._t = t; }
  list(params = {}) { return this._t.request('GET', '/health-keys', { params }); }
  create(body) { return this._t.request('POST', '/health-keys', { body }); }
  get(id) { return this._t.request('GET', `/health-keys/${id}`); }
  /** Patient authorizes. READY → ACTIVE. Requires funding_state = FUNDED. */
  authorize(id, { confirmationArtifact = '' } = {}) {
    return this._t.request('POST', `/health-keys/${id}/authorize`, {
      body: { patient_confirmation: true, confirmation_artifact: confirmationArtifact }
    });
  }
  /** Proof of Service. ACTIVE → COMPLETED. Settlement is immediate. */
  complete(id, body) { return this._t.request('POST', `/health-keys/${id}/complete`, { body }); }
  cancel(id, body) { return this._t.request('POST', `/health-keys/${id}/cancel`, { body }); }
  getQR(id, format = 'json') { return this._t.request('GET', `/health-keys/${id}/qr`, { params: { format } }); }
  /** Scan and verify. The boarding-pass moment. */
  scan(qrToken, scannerProviderId) {
    const body = { qr_token: qrToken };
    if (scannerProviderId) body.scanner_provider_id = scannerProviderId;
    return this._t.request('POST', '/scan', { body });
  }
}

class Funding {
  constructor(t) { this._t = t; }
  get(healthKeyId) { return this._t.request('GET', `/health-keys/${healthKeyId}/funding`); }
  add(healthKeyId, body) { return this._t.request('POST', `/health-keys/${healthKeyId}/funding`, { body }); }
  createLink(body) { return this._t.request('POST', '/funding-links', { body }); }
}

class Settlement {
  constructor(t) { this._t = t; }
  get(healthKeyId) { return this._t.request('GET', `/health-keys/${healthKeyId}/settlement`); }
  createDispute(healthKeyId, body) { return this._t.request('POST', `/health-keys/${healthKeyId}/disputes`, { body }); }
}

class MembershipTiers {
  constructor(t) { this._t = t; }
  list(params = {}) { return this._t.request('GET', '/membership-tiers', { params }); }
  create(body) { return this._t.request('POST', '/membership-tiers', { body }); }
  get(id) { return this._t.request('GET', `/membership-tiers/${id}`); }
  update(id, body) { return this._t.request('PATCH', `/membership-tiers/${id}`, { body }); }
  activate(id) { return this._t.request('POST', `/membership-tiers/${id}/activate`); }
  retire(id) { return this._t.request('POST', `/membership-tiers/${id}/retire`); }
}

class Memberships {
  constructor(t) { this._t = t; }
  create(body) { return this._t.request('POST', '/memberships', { body }); }
  get(id) { return this._t.request('GET', `/memberships/${id}`); }
  renew(id, body) { return this._t.request('POST', `/memberships/${id}/renew`, { body }); }
  cancel(id, body) { return this._t.request('POST', `/memberships/${id}/cancel`, { body }); }
  /** Initiate excluded-service handoff (Rail B). */
  initiateExcludedService(id, body) { return this._t.request('POST', `/memberships/${id}/excluded-service`, { body }); }
}

class Consent {
  constructor(t) { this._t = t; }
  listGrants() { return this._t.request('GET', '/consent/grants'); }
  requestGrant(body) { return this._t.request('POST', '/consent/grants', { body }); }
  revokeGrant(id, body) { return this._t.request('POST', `/consent/grants/${id}/revoke`, { body }); }
}

class Audit {
  constructor(t) { this._t = t; }
  accessLog(params = {}) { return this._t.request('GET', '/audit/access-log', { params }); }
}

class Webhooks {
  constructor(t) { this._t = t; }
  list() { return this._t.request('GET', '/webhooks'); }
  create(body) { return this._t.request('POST', '/webhooks', { body }); }
  update(id, body) { return this._t.request('PATCH', `/webhooks/${id}`, { body }); }
  del(id) { return this._t.request('DELETE', `/webhooks/${id}`); }
  test(id, eventType = 'health_key.created') {
    return this._t.request('POST', `/webhooks/${id}/test`, { body: { event_type: eventType } });
  }
}

class PlatformClient {
  constructor(t) { this._t = t; }
  register(body) { return this._t.request('POST', '/clients', { body }); }
  me() { return this._t.request('GET', '/clients/me'); }
  usage(period = 'this_month') { return this._t.request('GET', '/clients/me/usage', { params: { period } }); }
}

// ── Main Client ──────────────────────────────────────────────

class OpenDoc {
  /**
   * @param {string} apiKey - Your API key (sk_sandbox_... or sk_live_...)
   * @param {object} [opts]
   * @param {string} [opts.baseUrl] - Override base URL
   * @param {number} [opts.timeout=30] - Request timeout in seconds
   * @param {number} [opts.maxRetries=2] - Max retries on 5xx/429
   */
  constructor(apiKey, opts = {}) {
    if (!apiKey) throw new Error('apiKey is required');

    const baseUrl = opts.baseUrl || (apiKey.startsWith('sk_sandbox_') ? SANDBOX_URL : PRODUCTION_URL);
    const transport = new Transport(apiKey, baseUrl, opts.timeout || 30, opts.maxRetries || 2);

    this.taxonomy = new Taxonomy(transport);
    this.hsos = new HSOs(transport);
    this.providers = new Providers(transport);
    this.offers = new Offers(transport);
    this.resolve = new Resolve(transport);
    this.patients = new Patients(transport);
    this.healthKeys = new HealthKeys(transport);
    this.funding = new Funding(transport);
    this.settlement = new Settlement(transport);
    this.membershipTiers = new MembershipTiers(transport);
    this.memberships = new Memberships(transport);
    this.consent = new Consent(transport);
    this.audit = new Audit(transport);
    this.webhooks = new Webhooks(transport);
    this.platform = new PlatformClient(transport);
  }
}

module.exports = {
  OpenDoc,
  OpenDocError,
  AuthenticationError,
  NotFoundError,
  InvalidStateTransitionError,
  ConsentRequiredError,
  RateLimitError,
};
