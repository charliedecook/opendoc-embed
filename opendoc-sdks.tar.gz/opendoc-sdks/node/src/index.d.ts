/**
 * OpenDoc Platform SDK for Node.js — TypeScript Definitions
 */

declare module '@opendoc/sdk' {

  // ── Error Types ──

  export class OpenDocError extends Error {
    code: string;
    status: number;
    details: Record<string, any>;
  }

  export class AuthenticationError extends OpenDocError {}
  export class NotFoundError extends OpenDocError {}
  export class InvalidStateTransitionError extends OpenDocError {}

  export class ConsentRequiredError extends OpenDocError {
    requiredTier: string;
    consentUrl: string;
  }

  export class RateLimitError extends OpenDocError {
    retryAfter: number;
  }

  // ── Core Types ──

  interface Pagination {
    next_cursor: string | null;
    has_more: boolean;
    total_count: number;
  }

  interface ListResponse<T> {
    data: T[];
    pagination: Pagination;
  }

  type HealthKeyState = 'READY' | 'ACTIVE' | 'DECISION_REQUIRED' | 'NOT_AUTHORIZED' | 'COMPLETED' | 'SETTLED' | 'CANCELLED';
  type ServiceState = 'S1_SELECTED' | 'S2_SCHEDULED' | 'S3_PRE_SERVICE' | 'S4_SERVICE_TIME' | 'S5_POS_EVALUATION' | 'S6_POS_CONFIRMED' | 'S7_FINALIZED';
  type PaymentState = 'P1_AUTHORIZED' | 'P2_ESCROWED' | 'P3_PENDING_POS' | 'P4_RELEASED' | 'P5_SETTLED';
  type FundingState = 'INITIATED' | 'FUNDING_IN_PROGRESS' | 'FUNDED' | 'LOCKED' | 'SERVICE_COMPLETED' | 'SETTLED' | 'REFUND_PENDING' | 'REFUNDED' | 'CANCELLED';
  type ConsentTier = 'TIER1' | 'TIER2' | 'TIER3';
  type FundingSourceType = 'PATIENT' | 'INDIVIDUAL' | 'CHARITY' | 'EMPLOYER' | 'BNPL';
  type IntentType = 'COMPLAINT' | 'DIAGNOSIS' | 'REQUESTED_SERVICE';
  type PosType = 'TIME_BASED' | 'EMR_CONNECTED' | 'ARTIFACT_UPLOADED' | 'EMR_PLUS_ARTIFACT' | 'MANUAL_OVERRIDE';

  interface HSO {
    hso_id: string;
    hso_alias: string;
    name: string;
    specialty: string;
    subspecialty: string;
    category: string;
    specific: string;
    description?: string;
    scope: { included: string[]; excluded: string[] };
    constraints?: { age_min?: number; age_max?: number; sex?: string; requires_prior_hso?: string };
    inputs_required?: string[];
    outputs_expected?: string[];
    medicare_exclusion?: { excluded: boolean; exclusion_type?: string; exclusion_reason?: string };
    membership_eligible: boolean;
    consumer_search_terms: string[];
    active_offer_count?: number;
  }

  interface Provider {
    provider_id: string;
    status: 'PENDING' | 'VERIFIED' | 'SUSPENDED';
    display_name: string;
    legal_name?: string;
    npi: string;
    specialty: string;
    subspecialty?: string;
    credentials: string[];
    locations: ProviderLocation[];
    capabilities: string[];
    operational_signals?: OperationalSignals;
    medicare_opted_out: boolean;
    accepting_new_patients: boolean;
    telehealth_available: boolean;
    created_at: string;
  }

  interface ProviderLocation {
    location_id: string;
    name: string;
    address: { street: string; city: string; state: string; postal_code: string };
    geo?: { lat: number; lng: number };
    facility_type: string;
  }

  interface OperationalSignals {
    acceptance_rate?: number;
    cancellation_rate?: number;
    average_settlement_days?: number;
    dispute_rate?: number;
    transactability_score: number;
  }

  interface Offer {
    offer_id: string;
    provider_id: string;
    provider_display_name: string;
    hso_id: string;
    hso_name: string;
    location_id: string;
    location: ProviderLocation;
    price: { amount_cents: number; currency: string; immutable_once_accepted: boolean };
    availability?: { next_available: string; slots_this_week: number };
    distance_minutes?: number;
    transactability_score: number;
    binding_mode: string;
    active: boolean;
    created_at: string;
  }

  interface HealthKey {
    health_key_id: string;
    health_key_type: 'EPISODIC' | 'MEMBERSHIP';
    patient: { patient_id: string; full_name: string; date_of_birth: string };
    provider: { provider_id: string; display_name: string; location: ProviderLocation };
    service: { hso_id: string; hso_name: string; offer_id: string; scope: { included: string[]; excluded: string[] } };
    state: HealthKeyState;
    exposure_boundary: { max_patient_responsibility_cents: number; currency: string };
    funding_state: FundingState;
    service_state: ServiceState;
    payment_state: PaymentState;
    valid_transitions: string[];
    scheduled_at?: string;
    qr_token: string;
    created_at: string;
    updated_at: string;
    last_sync_at: string;
  }

  interface ResolveResponse {
    resolution_id: string;
    input_hash: string;
    policy_version: string;
    consent_tier_used: ConsentTier;
    hso_candidates: Array<{ hso_id: string; hso_label: string; confidence: number; reason_codes: string[] }>;
    provider_candidates: Array<{ provider_id: string; display_name: string; offer_id: string; transactability_score: number; distance_minutes: number; reason_codes: string[] }>;
    pricing: { cash_price_cents: number; currency: string; pricing_confidence: 'HIGH' };
    confirmation_url: string;
    required_patient_confirmation: true;
    disclaimer_code: 'NOT_MEDICAL_ADVICE';
  }

  interface Patient {
    patient_id: string;
    full_name: string;
    full_name_upper: string;
    date_of_birth: string;
    email?: string;
    phone?: string;
    external_id?: string;
    created_at: string;
  }

  interface FundingStatus {
    health_key_id: string;
    state: FundingState;
    required_upfront_cents: number;
    total_funded_cents: number;
    remaining_cents: number;
    contributions: Array<{
      contribution_id: string;
      source_type: FundingSourceType;
      amount_cents: number;
      escrow_status: string;
      refund_amount_cents?: number;
      funder_display_name?: string;
      created_at: string;
    }>;
  }

  interface SettlementStatus {
    health_key_id: string;
    payment_state: PaymentState;
    service_state: ServiceState;
    escrow: { total_escrowed_cents: number; created_at: string };
    release?: { released_cents: number; released_at: string; pos_tier: number };
    dispute_window?: { opens_at: string; closes_at: string; is_open: boolean };
    finality?: { finalized_at: string; is_final: boolean };
  }

  // ── Resource Classes ──

  interface TaxonomyResource {
    listComplaints(params?: { q?: string; specialty?: string; cursor?: string; limit?: number }): Promise<ListResponse<any>>;
    getComplaint(id: string): Promise<any>;
    listDiagnoses(params?: { q?: string; specialty?: string; cursor?: string; limit?: number }): Promise<ListResponse<any>>;
    getDiagnosis(id: string): Promise<any>;
    listScopeCodes(params?: { type?: string; category?: string }): Promise<any>;
    listSpecialties(): Promise<any>;
  }

  interface HSOsResource {
    list(params?: { specialty?: string; q?: string; geo?: string; radius_miles?: number; medicare_excluded?: boolean; membership_eligible?: boolean; cursor?: string; limit?: number }): Promise<ListResponse<HSO>>;
    get(hsoId: string): Promise<HSO>;
    listOffers(hsoId: string, params?: { geo?: string; radius_miles?: number }): Promise<ListResponse<Offer>>;
  }

  interface ProvidersResource {
    list(params?: { q?: string; specialty?: string; geo?: string; radius_miles?: number; medicare_opted_out?: boolean; accepting_new_patients?: boolean }): Promise<ListResponse<Provider>>;
    create(body: { npi: string; display_name: string; specialty: string; locations: any[] }): Promise<Provider>;
    get(id: string): Promise<Provider>;
    update(id: string, body: Partial<Provider>): Promise<Provider>;
    listOffers(id: string, params?: object): Promise<ListResponse<Offer>>;
  }

  interface OffersResource {
    create(body: { provider_id: string; hso_id: string; location_id: string; price_cents: number; binding_mode?: string }): Promise<Offer>;
    get(id: string): Promise<Offer>;
    update(id: string, body: { price_cents?: number; active?: boolean }): Promise<Offer>;
    retire(id: string): Promise<Offer>;
  }

  interface ResolveResource {
    toCare(body: { intent_type: IntentType; intent_id: string; geo: { postal_code: string; lat?: number; lng?: number }; patient_id?: string; time_window?: object; financial_context?: object; patient_preferences?: object }): Promise<ResolveResponse>;
  }

  interface PatientsResource {
    create(body: { full_name: string; date_of_birth: string; email?: string; phone?: string; external_id?: string }): Promise<Patient>;
    get(id: string): Promise<Patient>;
  }

  interface HealthKeysResource {
    list(params?: { patient_id?: string; provider_id?: string; state?: HealthKeyState | HealthKeyState[]; created_after?: string; created_before?: string }): Promise<ListResponse<HealthKey>>;
    create(body: { patient_id: string; offer_id: string; resolution_id?: string; scheduled_at?: string }): Promise<HealthKey>;
    get(id: string): Promise<HealthKey>;
    authorize(id: string, opts?: { confirmationArtifact?: string }): Promise<HealthKey>;
    complete(id: string, body: { pos_type: PosType; pos_tier?: number; attested_by?: string; artifacts?: any[] }): Promise<HealthKey>;
    cancel(id: string, body: { initiated_by: 'PATIENT' | 'PROVIDER' | 'SYSTEM'; reason?: string }): Promise<HealthKey>;
    getQR(id: string, format?: 'json' | 'png' | 'svg'): Promise<any>;
    scan(qrToken: string, scannerProviderId?: string): Promise<any>;
  }

  interface FundingResource {
    get(healthKeyId: string): Promise<FundingStatus>;
    add(healthKeyId: string, body: { source_type: FundingSourceType; amount_cents: number; payment_method_token: string; funder_id?: string }): Promise<FundingStatus>;
    createLink(body: { health_key_id: string; funder_type?: string; suggested_amount_cents?: number; expires_at?: string }): Promise<{ funding_link_id: string; url: string; expires_at: string }>;
  }

  interface SettlementResource {
    get(healthKeyId: string): Promise<SettlementStatus>;
    createDispute(healthKeyId: string, body: { reason: string; description?: string; evidence_refs?: string[] }): Promise<any>;
  }

  interface MembershipTiersResource {
    list(params?: object): Promise<ListResponse<any>>;
    create(body: { provider_id: string; name: string; template: string; fee_cents: number; fee_cadence: string; term_months: number; included_scope: string[]; excluded_scope: string[] }): Promise<any>;
    get(id: string): Promise<any>;
    update(id: string, body: object): Promise<any>;
    activate(id: string): Promise<any>;
    retire(id: string): Promise<any>;
  }

  interface MembershipsResource {
    create(body: { patient_id: string; tier_id: string; payment_method_id: string; renewal_mode?: string }): Promise<any>;
    get(id: string): Promise<any>;
    renew(id: string, body?: object): Promise<any>;
    cancel(id: string, body?: object): Promise<any>;
    initiateExcludedService(id: string, body: { hso_id: string; preferred_provider_id?: string; notes?: string }): Promise<any>;
  }

  interface ConsentResource {
    listGrants(): Promise<any>;
    requestGrant(body: { patient_id: string; tier: ConsentTier; purpose: string; grant_type?: string; scopes?: string[] }): Promise<any>;
    revokeGrant(id: string, body?: { reason?: string }): Promise<any>;
  }

  interface AuditResource {
    accessLog(params?: { client_id?: string; since?: string; cursor?: string; limit?: number }): Promise<ListResponse<any>>;
  }

  interface WebhooksResource {
    list(): Promise<any>;
    create(body: { url: string; events: string[] }): Promise<any>;
    update(id: string, body: { url?: string; events?: string[]; status?: string }): Promise<any>;
    del(id: string): Promise<void>;
    test(id: string, eventType?: string): Promise<any>;
  }

  interface PlatformResource {
    register(body: { name: string; redirect_uris: string[]; contact_email: string }): Promise<any>;
    me(): Promise<any>;
    usage(period?: string): Promise<any>;
  }

  // ── Main Client ──

  export class OpenDoc {
    constructor(apiKey: string, opts?: { baseUrl?: string; timeout?: number; maxRetries?: number });

    taxonomy: TaxonomyResource;
    hsos: HSOsResource;
    providers: ProvidersResource;
    offers: OffersResource;
    resolve: ResolveResource;
    patients: PatientsResource;
    healthKeys: HealthKeysResource;
    funding: FundingResource;
    settlement: SettlementResource;
    membershipTiers: MembershipTiersResource;
    memberships: MembershipsResource;
    consent: ConsentResource;
    audit: AuditResource;
    webhooks: WebhooksResource;
    platform: PlatformResource;
  }
}
