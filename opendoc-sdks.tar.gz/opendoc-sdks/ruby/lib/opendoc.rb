# frozen_string_literal: true

#
# OpenDoc Platform SDK for Ruby
#
# Healthcare transaction infrastructure. Resolve intent to bounded,
# pre-priced healthcare transactions.
#
# @example
#   client = OpenDoc::Client.new(api_key: "sk_sandbox_...")
#
#   resolution = client.resolve.to_care(
#     intent_type: "COMPLAINT",
#     intent_id: "complaint.knee_pain",
#     geo: { postal_code: "30114" }
#   )
#
#   health_key = client.health_keys.create(
#     patient_id: "...",
#     offer_id: resolution.dig("provider_candidates", 0, "offer_id")
#   )
#

require "net/http"
require "json"
require "uri"

module OpenDoc
  VERSION = "1.1.0"
  PRODUCTION_URL = "https://api.opendoc.com/v1"
  SANDBOX_URL = "https://sandbox.api.opendoc.com/v1"

  # ── Errors ──────────────────────────────────────────────────

  class Error < StandardError
    attr_reader :code, :status, :details

    def initialize(code, message, status: 400, details: {})
      @code = code
      @status = status
      @details = details
      super("[#{code}] #{message}")
    end
  end

  class AuthenticationError < Error; end
  class NotFoundError < Error; end
  class InvalidStateTransitionError < Error; end
  class ValidationError < Error; end

  class ConsentRequiredError < Error
    attr_reader :required_tier, :consent_url

    def initialize(message, details: {})
      @required_tier = details["required_tier"] || ""
      @consent_url = details["consent_url"] || ""
      super("CONSENT_REQUIRED", message, status: 403, details: details)
    end
  end

  class RateLimitError < Error
    attr_reader :retry_after

    def initialize(message, retry_after: 60)
      @retry_after = retry_after
      super("RATE_LIMITED", message, status: 429)
    end
  end

  # ── Transport ───────────────────────────────────────────────

  class Transport
    def initialize(api_key:, base_url:, timeout:, max_retries:)
      @api_key = api_key
      @base_url = base_url.chomp("/")
      @timeout = timeout
      @max_retries = max_retries
    end

    def request(method, path, params: nil, body: nil, idempotency_key: nil)
      url = "#{@base_url}#{path}"
      if params
        filtered = params.compact
        url += "?#{URI.encode_www_form(filtered)}" unless filtered.empty?
      end

      uri = URI.parse(url)
      last_error = nil

      (@max_retries + 1).times do |attempt|
        http = Net::HTTP.new(uri.host, uri.port)
        http.use_ssl = uri.scheme == "https"
        http.open_timeout = @timeout
        http.read_timeout = @timeout

        req = build_request(method, uri, body, idempotency_key)

        begin
          response = http.request(req)
          parsed = response.body ? JSON.parse(response.body) : {}
          code = response.code.to_i

          return parsed if code >= 200 && code < 300

          error_code = parsed["code"] || "UNKNOWN"
          error_msg = parsed["message"] || "HTTP #{code}"
          details = parsed["details"] || {}

          case code
          when 401
            raise AuthenticationError.new(error_code, error_msg, status: code, details: details)
          when 403
            if error_code == "CONSENT_REQUIRED"
              raise ConsentRequiredError.new(error_msg, details: details)
            end
            raise Error.new(error_code, error_msg, status: code, details: details)
          when 404
            raise NotFoundError.new(error_code, error_msg, status: code, details: details)
          when 409
            if error_code == "INVALID_STATE_TRANSITION"
              raise InvalidStateTransitionError.new(error_code, error_msg, status: code, details: details)
            end
            raise Error.new(error_code, error_msg, status: code, details: details)
          when 429
            retry_after = (response["Retry-After"] || "60").to_i
            if attempt < @max_retries
              sleep(retry_after)
              next
            end
            raise RateLimitError.new(error_msg, retry_after: retry_after)
          when 500..599
            if attempt < @max_retries
              sleep(2**attempt)
              last_error = Error.new(error_code, error_msg, status: code, details: details)
              next
            end
            raise Error.new(error_code, error_msg, status: code, details: details)
          else
            raise Error.new(error_code, error_msg, status: code, details: details)
          end
        rescue Timeout::Error, Errno::ECONNREFUSED => e
          if attempt < @max_retries
            sleep(2**attempt)
            last_error = e
            next
          end
          raise Error.new("TIMEOUT", e.message, status: 0)
        end
      end

      raise last_error if last_error
    end

    private

    def build_request(method, uri, body, idempotency_key)
      klass = case method.upcase
              when "GET"    then Net::HTTP::Get
              when "POST"   then Net::HTTP::Post
              when "PATCH"  then Net::HTTP::Patch
              when "DELETE" then Net::HTTP::Delete
              when "PUT"    then Net::HTTP::Put
              else raise "Unsupported method: #{method}"
              end

      req = klass.new(uri)
      req["Authorization"] = "Bearer #{@api_key}"
      req["Content-Type"] = "application/json"
      req["User-Agent"] = "opendoc-ruby/#{VERSION}"
      req["Idempotency-Key"] = idempotency_key if idempotency_key
      req.body = JSON.generate(body) if body
      req
    end
  end

  # ── Resource Classes ────────────────────────────────────────

  class Taxonomy
    def initialize(transport) = @t = transport
    def list_complaints(**params) = @t.request("GET", "/taxonomy/complaints", params: params)
    def get_complaint(id) = @t.request("GET", "/taxonomy/complaints/#{id}")
    def list_diagnoses(**params) = @t.request("GET", "/taxonomy/diagnoses", params: params)
    def get_diagnosis(id) = @t.request("GET", "/taxonomy/diagnoses/#{id}")
    def list_scope_codes(**params) = @t.request("GET", "/taxonomy/scope-codes", params: params)
    def list_specialties = @t.request("GET", "/taxonomy/specialties")
  end

  class HSOs
    def initialize(transport) = @t = transport
    def list(**params) = @t.request("GET", "/hsos", params: params)
    def get(hso_id) = @t.request("GET", "/hsos/#{hso_id}")
    def list_offers(hso_id, **params) = @t.request("GET", "/hsos/#{hso_id}/offers", params: params)
  end

  class Providers
    def initialize(transport) = @t = transport
    def list(**params) = @t.request("GET", "/providers", params: params)
    def create(**body) = @t.request("POST", "/providers", body: body)
    def get(id) = @t.request("GET", "/providers/#{id}")
    def update(id, **body) = @t.request("PATCH", "/providers/#{id}", body: body)
    def list_offers(id, **params) = @t.request("GET", "/providers/#{id}/offers", params: params)
  end

  class Offers
    def initialize(transport) = @t = transport
    # Create an offer. The price must be the real, deliverable cash price.
    def create(**body) = @t.request("POST", "/offers", body: body)
    def get(id) = @t.request("GET", "/offers/#{id}")
    # Update price or availability. Prospective only — Cash Price Invariant enforced.
    def update(id, **body) = @t.request("PATCH", "/offers/#{id}", body: body)
    def retire(id) = @t.request("DELETE", "/offers/#{id}")
  end

  class Resolve
    def initialize(transport) = @t = transport

    # Resolve patient intent to bounded transaction candidates.
    # All prices returned are cash prices. Always HIGH confidence.
    def to_care(**body) = @t.request("POST", "/resolve", body: body)
  end

  class Patients
    def initialize(transport) = @t = transport
    def create(**body) = @t.request("POST", "/patients", body: body)
    def get(id) = @t.request("GET", "/patients/#{id}")
  end

  class HealthKeys
    def initialize(transport) = @t = transport
    def list(**params) = @t.request("GET", "/health-keys", params: params)
    def create(**body) = @t.request("POST", "/health-keys", body: body)
    def get(id) = @t.request("GET", "/health-keys/#{id}")

    # Patient authorizes. READY → ACTIVE. Requires funding_state = FUNDED.
    def authorize(id, confirmation_artifact: "")
      @t.request("POST", "/health-keys/#{id}/authorize",
        body: { patient_confirmation: true, confirmation_artifact: confirmation_artifact })
    end

    # Proof of Service. ACTIVE → COMPLETED. Settlement is immediate.
    def complete(id, **body) = @t.request("POST", "/health-keys/#{id}/complete", body: body)
    def cancel(id, **body) = @t.request("POST", "/health-keys/#{id}/cancel", body: body)
    def get_qr(id, format: "json") = @t.request("GET", "/health-keys/#{id}/qr", params: { format: format })

    # Scan and verify. The boarding-pass moment.
    def scan(qr_token, scanner_provider_id: nil)
      body = { qr_token: qr_token }
      body[:scanner_provider_id] = scanner_provider_id if scanner_provider_id
      @t.request("POST", "/scan", body: body)
    end
  end

  class Funding
    def initialize(transport) = @t = transport
    def get(health_key_id) = @t.request("GET", "/health-keys/#{health_key_id}/funding")
    def add(health_key_id, **body) = @t.request("POST", "/health-keys/#{health_key_id}/funding", body: body)
    def create_link(**body) = @t.request("POST", "/funding-links", body: body)
  end

  class Settlement
    def initialize(transport) = @t = transport
    def get(health_key_id) = @t.request("GET", "/health-keys/#{health_key_id}/settlement")
    def create_dispute(health_key_id, **body) = @t.request("POST", "/health-keys/#{health_key_id}/disputes", body: body)
  end

  class MembershipTiers
    def initialize(transport) = @t = transport
    def list(**params) = @t.request("GET", "/membership-tiers", params: params)
    def create(**body) = @t.request("POST", "/membership-tiers", body: body)
    def get(id) = @t.request("GET", "/membership-tiers/#{id}")
    def update(id, **body) = @t.request("PATCH", "/membership-tiers/#{id}", body: body)
    def activate(id) = @t.request("POST", "/membership-tiers/#{id}/activate")
    def retire(id) = @t.request("POST", "/membership-tiers/#{id}/retire")
  end

  class Memberships
    def initialize(transport) = @t = transport
    def create(**body) = @t.request("POST", "/memberships", body: body)
    def get(id) = @t.request("GET", "/memberships/#{id}")
    def renew(id, **body) = @t.request("POST", "/memberships/#{id}/renew", body: body.empty? ? nil : body)
    def cancel(id, reason: nil) = @t.request("POST", "/memberships/#{id}/cancel", body: reason ? { reason: reason } : nil)

    # Initiate excluded-service handoff (Rail B).
    def initiate_excluded_service(id, **body) = @t.request("POST", "/memberships/#{id}/excluded-service", body: body)
  end

  class ConsentManager
    def initialize(transport) = @t = transport
    def list_grants = @t.request("GET", "/consent/grants")
    def request_grant(**body) = @t.request("POST", "/consent/grants", body: body)
    def revoke_grant(id, reason: nil) = @t.request("POST", "/consent/grants/#{id}/revoke", body: reason ? { reason: reason } : nil)
  end

  class Audit
    def initialize(transport) = @t = transport
    def access_log(**params) = @t.request("GET", "/audit/access-log", params: params)
  end

  class WebhooksManager
    def initialize(transport) = @t = transport
    def list = @t.request("GET", "/webhooks")
    def create(**body) = @t.request("POST", "/webhooks", body: body)
    def update(id, **body) = @t.request("PATCH", "/webhooks/#{id}", body: body)
    def delete(id) = @t.request("DELETE", "/webhooks/#{id}")
    def test(id, event_type: "health_key.created") = @t.request("POST", "/webhooks/#{id}/test", body: { event_type: event_type })
  end

  class PlatformManager
    def initialize(transport) = @t = transport
    def register(**body) = @t.request("POST", "/clients", body: body)
    def me = @t.request("GET", "/clients/me")
    def usage(period: "this_month") = @t.request("GET", "/clients/me/usage", params: { period: period })
  end

  # ── Main Client ─────────────────────────────────────────────

  class Client
    attr_reader :taxonomy, :hsos, :providers, :offers, :resolve, :patients,
                :health_keys, :funding, :settlement, :membership_tiers,
                :memberships, :consent, :audit, :webhooks, :platform

    # @param api_key [String] Your API key (sk_sandbox_... or sk_live_...)
    # @param base_url [String, nil] Override the base URL
    # @param timeout [Integer] Request timeout in seconds
    # @param max_retries [Integer] Max retries on 5xx/429
    def initialize(api_key:, base_url: nil, timeout: 30, max_retries: 2)
      raise ArgumentError, "api_key is required" if api_key.nil? || api_key.empty?

      base_url ||= api_key.start_with?("sk_sandbox_") ? SANDBOX_URL : PRODUCTION_URL
      transport = Transport.new(api_key: api_key, base_url: base_url, timeout: timeout, max_retries: max_retries)

      @taxonomy = Taxonomy.new(transport)
      @hsos = HSOs.new(transport)
      @providers = Providers.new(transport)
      @offers = Offers.new(transport)
      @resolve = Resolve.new(transport)
      @patients = Patients.new(transport)
      @health_keys = HealthKeys.new(transport)
      @funding = Funding.new(transport)
      @settlement = Settlement.new(transport)
      @membership_tiers = MembershipTiers.new(transport)
      @memberships = Memberships.new(transport)
      @consent = ConsentManager.new(transport)
      @audit = Audit.new(transport)
      @webhooks = WebhooksManager.new(transport)
      @platform = PlatformManager.new(transport)
    end
  end
end
