Gem::Specification.new do |s|
  s.name        = "opendoc"
  s.version     = "1.1.0"
  s.summary     = "OpenDoc Platform SDK"
  s.description = "Healthcare transaction infrastructure. Resolve intent to bounded, pre-priced healthcare transactions."
  s.authors     = ["OpenDoc"]
  s.email       = "platform@opendoc.com"
  s.homepage    = "https://github.com/opendoc/opendoc-ruby"
  s.license     = "Nonstandard"
  s.files       = Dir["lib/**/*.rb"]
  s.require_paths = ["lib"]
  s.required_ruby_version = ">= 3.0"
end
